import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './style.css';


export default class FormContainer extends Component{
  render(){
    return(
      <div className="col col-sm-11 col-md-11 col-lg-11 col-xl-11" id="page-wrapper">
        <div className="">
             <div className="row" id="main" >
                      <div className="col-sm-10 col-md-10 card" id="content">
                          <input type="text"/>
                      </div>
              </div>
         </div>
      </div>
    );
  }
}
