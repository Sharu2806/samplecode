import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from './components/app';
import CreateClause from './components/createClauseContainer';
import TableClause from './components/clauseTableContainer';

export default(
    <Route path="/" component={App}>
        <Route path="/clause" component={CreateClause}/>
        <Route path="tableClause" component={TableClause}/>
    </Route>
);
