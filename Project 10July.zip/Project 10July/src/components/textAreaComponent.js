import React, { Component } from 'react';

export default class TextAreaClause extends Component {
  render() {
    return (
      <div>
          <div className="row control-padding">
            <div className="col-lg-3">
                Clause Text
            </div>
            <div className="col-lg-3">
                <textarea />
            </div>
            <div className="col-lg-6"></div>
        </div>
      </div>
    );
  }
}
