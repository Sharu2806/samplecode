import React, { Component } from 'react';
import TopNavigation from './SideNavigation';

export default class App extends Component {
  render() {
    return (
      <div>
        <TopNavigation />
        <div className="col col-sm-11 col-md-11 col-lg-11 col-xl-11" id="page-wrapper">
          <div className="">
               <div className="row" id="main" >
                        <div className="col-sm-10 col-md-10 card" id="content">
                            {this.props.children}
                        </div>
                </div>
           </div>
        </div>
      </div>
    );
  }
}
