import React, { Component } from 'react';
import ListItem from './ListItem';

export default class InputDropdownComponent extends Component {
  constructor(props){
    super(props);
    this.state = {
      listOptions:[
                        {"id":1,"accountType":"PLEASE SELECT"},
                        {"id":2,"accountType":"ADVICE MAINTENANCE CLAUSE"},
                        {"id":3,"accountType":"ADVICE OF FATE"},
                        {"id":4,"accountType":"AIRMAIL REIMB INSTR"},
                        {"id":5,"accountType":"AMOUNTS ADDED"},
                        {"id":6,"accountType":"BANK TO BANK INSTRUCTIONS"},
                        {"id":7,"accountType":"BILL DISCREPANCY - CABLE"},
                        {"id":8,"accountType":"BILL NARRATIVE - CABLE"},
                        {"id":9,"accountType":"NARRATIVE - CABLE"},
                        {"id":10,"accountType":"BILL OTHER INFO"},
                        {"id":11,"accountType":"CHRGES CLAIMED"},
                        {"id":12,"accountType":"CHRGES DEDUCTED"},
                        {"id":13,"accountType":"DC ENDING CLAUSES"},
                        {"id":14,"accountType":"DC NARRATIVE"},
                        {"id":15,"accountType":"DC OPENING CLAUSES"},
                        {"id":16,"accountType":"DC REIMB INSTR"},
                        {"id":17,"accountType":"DESCRIPTION OF GOODS"},
                        {"id":18,"accountType":"DESCRIPTION OF GOODS FOR BRIEF CABLE"},
                        {"id":19,"accountType":"DISCREPANCY"},
                        {"id":20,"accountType":"DISPOSAL OF DOC"},
                        {"id":21,"accountType":"DOCUMENT MODEL"},
                        {"id":22,"accountType":"DOCUMENTS REQUIRED"},
                        {"id":23,"accountType":"DRAFT AT"},
                        {"id":24,"accountType":"EXPORT BILL NARRATIVE"},
                        {"id":25,"accountType":"FATE ADVICE NARRATIVE"},
                        {"id":26,"accountType":"IMP DC CLOSING CLAUSES"},
                        {"id":27,"accountType":"IMP DC OPENING CLAUSES"},
                        {"id":28,"accountType":"IMPORT BILL NARRATIVE"},
                        {"id":29,"accountType":"IMPORTS REMARKS"},
                        {"id":30,"accountType":"INFORMATION TO PRESENTING BANK"},
                        {"id":31,"accountType":"NARRATIVES"},
                        {"id":32,"accountType":"OTHER AMENDMENTS"},
                        {"id":33,"accountType":"PAYMENT DETAILS"},
                        {"id":34,"accountType":"PRESENTATION CONDITIONS"},
                        {"id":35,"accountType":"REASON FOR REFU"},
                        {"id":36,"accountType":"REIMB NARRATIVE"},
                        {"id":37,"accountType":"REMARKS"},
                        {"id":38,"accountType":"REQ FOR INFO"},
                        {"id":39,"accountType":"SCHEDULE INFO"},
                        {"id":40,"accountType":"USANCE TYPE "}
                ],
      selectedValue:'PLEASE SELECT'
  };
  this.onChange = this.onChange.bind(this);
  }
  renderOptions(){
  this.options=  this.state.listOptions.map((item,index)=>{
      return(
        <li onClick={(event)=>this.itemClickHandler(event,item)}>{item.accountType}</li>
      )
    })
    return this.options
  }
  itemClickHandler(event,item){
   this.props.validateDropdown(event.target.innerHTML,item)
  }
    onChange(event){
      if(event.target.textContent===""){
        this.setState({selectedValue:""});
      }else{
        this.setState({selectedValue:event.target.textContent});
      }
    }
    render() {

        return (
            <div className="form-group">
                <div className="dropdown">
                        <button className="btn formButtonStyle dropdown-toggle inputtextboxstyle" type="button" data-toggle="dropdown">
                                <span className="dropdownlabelstyle">{this.state.selectedValue}</span><span className="caret"></span></button>
                                 <ul className="dropdown-menu" onClick={this.onChange}>
                                {this.renderOptions()}
                            </ul>
                    </div>
            </div>
        );
    }
}
