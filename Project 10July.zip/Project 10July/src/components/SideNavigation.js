import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import '../style.css'

export default class TopNavigation extends Component{
  render(){
    return(
        <div className="wrapper navbar-inverse navbar-fixed-top">
              <nav className="navbar col col-sm-12 col-md-12 col-lg-12 col-xl-12">
                
              </nav>
              <div className="sidebar col col-sm-2 col-md-2 col-lg-2 col-xl-2">
                <div className="sidebar-logo">
                      <img src="Assets/HSBC_LOGO.png" width="200" height="30"  alt="Generic placeholder thumbnail"></img>
                      <div className="user-name">

                            <span>Jane Deo</span>
                            <button className="btn-logout">Logout</button>
                      </div>
                </div>
                <ul className="nav nav-pills flex-column ">
                    <li className="nav-item">
                        <a href="#" className="nav-link">
                            <img src="Assets/Home.png" width="30" height="30"  alt="Generic placeholder thumbnail"></img>
                            <span>Home</span>
                        </a>
                    </li>
                    <li className="nav-item">
                        <a href="#" className="nav-link">
                            <img src="Assets/customer.png" width="30" height="30"  alt="Generic placeholder thumbnail"></img>
                            <span>Customers</span>
                        </a>
                    </li>
                    <li className="nav-item">
                        <a href="#" className="nav-link" data-toggle="dropdown">
                            <img src="Assets/trade_services.png" width="30" height="30"  alt="Generic placeholder thumbnail"></img>
                            <span>Trade Services</span>
                        </a>
                            <ul role="menu">
                                <li className="nav-item"><a className="nav-link" href="#"><span>Capture</span></a></li>
                                <li className="nav-item"><a className="nav-link" href="#"><span>Approval</span></a></li>
                                <li className="nav-item"><a className="nav-link" href="#"><span>Cancellation</span></a></li>
                                <li className="nav-item"><a className="nav-link" href="#"><span>Maintenance</span></a>
                                    <ul role="menu">

                                        <li className="nav-item">
                                            <a className="nav-link" href="/clause">Standard Clause</a>
                                        </li>

                                    </ul>
                                 </li>
                            </ul>

                    </li>
                    <li className="nav-item">
                        <a href="#" className="nav-link">
                              <img src="Assets/Administration.png" width="30" height="30"  alt="Generic placeholder thumbnail"></img>
                              <span>Administration</span>
                        </a>
                    </li>
                </ul>
              </div>

          </div>



  )
  }
}
