import React, { Component,PropTypes } from 'react';
import { Link } from 'react-router';

export default class ShowClause extends Component {
  static contextTypes={
    router:PropTypes.object
  };
  constructor(props){
      super(props);
      this.state ={
        clauseText:this.props.clauseDataList.clauseText,
        fieldsRejected:false,
        textAreaInvalid:false
      };
      this.handleInputChange = this.handleInputChange.bind(this);
  }
  handleInputChange(event) {
      const target = event.target;
      const name = target.name;
      this.setState({
        [name]: target.value
      });
    }
    submitClause(){
  var textInput=React.findDOMNode(this.refs.clause_text).value;
  if(textInput===""){
    this.setState({fieldsRejected:true, textAreaInvalid:true }) ,
    () => {console.log(this.state.fieldsRejected)}
  }else{
    this.setState({fieldsRejected:false,textAreaInvalid:false})

      alert("Standard clause created!")
      this.props.redirectToHome()

  }

    }
  render() {
    return (
      <div>
        <div className="container">
        {this.state.fieldsRejected?<div className="errorMessage">FE rejected</div>:null}
        {this.state.textAreaInvalid?<div className="errorMessage">Clause text cannot be blank</div>:null}
            <div className="row">

            <div className="row">

                <div className="col-lg-6">
                          <div className="row control-padding">
                               <div className="col-lg-6">
                                   Country Code
                               </div>
                               <div className="col-lg-6">
                                   <label>JP</label>
                               </div>
                          </div>
                          <div className="row control-padding">
                               <div className="col-lg-6">
                                   Clause Type
                               </div>
                               <div className="col-lg-6">
                                   <label>{this.props.clauseDataList.clauseType}</label>
                               </div>
                          </div>
                          <div className="row control-padding">
                               <div className="col-lg-6">
                                   Clause Code
                               </div>
                               <div className="col-lg-6">
                                   <label>{this.props.clauseDataList.clauseCode}</label>
                               </div>
                          </div>
                      </div>
                      <div className="col-lg-6">
                          <div className="row control-padding">
                               <div className="col-lg-6">
                                   Group Member
                               </div>
                               <div className="col-lg-6">
                                   <label>HSBC</label>
                               </div>
                          </div>
                  </div>
                  <div className="col-lg-12 control-padding">
                      <div>
                          <div className="row control-padding">
                            <div className="col-lg-3">
                                Clause Text
                            </div>
                            <div className="col-lg-3">
                                <textarea maxLength="66" ref="clause_text" className="textAreawidthheigth" name="clauseText" value={this.state.clauseText}
                                    onChange={this.handleInputChange}/>
                            </div>
                            <div className="col-lg-6"></div>
                        </div>
                      </div>
                      <div className="col-lg-6"></div>
                      <div className="col-lg-6">
                           <button type="submit" className="btn btn-primary control-margin" onClick={()=>this.submitClause()}>Submit</button>
                           <button className="btn btn-primary control-margin"  >Delete</button>
                           <button className="btn btn-primary control-margin" onClick={this.props.redirectToHome}>Exit</button>
                      </div>
                  </div>
            </div>
            </div>
        </div>
      </div>
    );
  }
}
