import React, { Component,PropTypes } from 'react';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import { fetchClause } from '../actions/index';
import ShowClause from './showClauseComponent';

class TableClause extends Component {
  componentWillMount(){
    this.props.fetchClause();
  }
  static contextTypes={
    router:PropTypes.object
  };
  constructor(props){
      super(props);
      this.state ={clauseCode:"",groupMember:"HSBC",showClauseTable:true,showClauseForm:false};
      this.redirectToHome = this.redirectToHome.bind(this);
  }
  dataToLoaded(clauseCode){

    const resultData ={};
    if(this.props.data.ResultList){
      for(var i=0;i<this.props.data.ResultList.length;i++){
        if(this.props.data.ResultList[i].clauseCode==clauseCode){
          this.resultData=this.props.data.ResultList[i];
        }
      }
      this.setState({showClauseTable:false,showClauseForm:true});
    }
  }

  redirectToHome(){
    this.setState({showClauseTable:false,showClauseForm:false});
    this.context.router.push('/clause');
  }
  renderClauseData(){
      if(this.props.data.ResultList){
        return this.props.data.ResultList.map((clause)=>{
          return(
              <tr>
                <td><a href="#" onClick={()=>this.dataToLoaded(clause.clauseCode)}>{clause.clauseCode}</a></td>
                <td>{clause.clauseType}</td>
                <td>{clause.clauseText}</td>
              </tr>
        );
      });
      }
  }
  render() {
    if(!this.props){
      return <div>Loading....</div>
    }
   else {
    return (
      <div className="col-lg-12">
      {this.state.showClauseTable ?
            <div>
            <table className="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Clause Code</th>
                    <th>Clause Type</th>
                    <th>Clause Text</th>
                </tr>
                </thead>
                <tbody>
                    {this.renderClauseData()}
                </tbody>
            </table>
            <Link to="/clause" className="btn btn-primary control-margin">Back</Link>
            </div>
            :null}
            {this.state.showClauseForm ?<ShowClause clauseDataList={this.resultData} redirectToHome={this.redirectToHome}/>:null}
      </div>
    );
  }
  }
}

function mapStateToProps(state){
  return { data:state.clauseData.all};
}

export default connect(mapStateToProps, { fetchClause})(TableClause);
