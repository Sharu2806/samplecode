import React, { Component,PropTypes } from 'react';
import TextAreaClause from './textAreaComponent';
import { Link } from 'react-router';
import InputDropdownComponent from './dropdownComponent';
import ShowClause from './showClauseComponent';
import { connect } from 'react-redux';
import { fetchClause,saveClauseCreate } from '../actions/index';


class FormClause extends Component {
  static contextTypes={
    router:PropTypes.object
  };

  componentWillMount(){
    this.props.fetchClause();
  }
 dataToLoaded(clauseCode){
   const resultData ={};
   if(this.props.data.ResultList){
     for(var i=0;i<this.props.data.ResultList.length;i++){
       if(this.props.data.ResultList[i].clauseCode==clauseCode){
         this.resultData=this.props.data.ResultList[i];
       }
     }
   }
 }

 dataToLoadedCreate(clauseCode){
   const resultData ={};
   var flag=true;
   if(this.props.data.ResultList){
     for(var i=0;i<this.props.data.ResultList.length;i++){
       if(this.props.data.ResultList[i].clauseCode==clauseCode){
         //error message for duplicate clause code
         alert("Record Already Existing");
         flag=false;
       }
     }
   }
   return flag;
 }

 redirectToHome(){
   this.setState({showClauseTab:false,showClauseForm:true,clauseCode:""});
 }

  constructor(props){
      super(props);
      this.state ={
        clauseCode:"",
        groupMember:"HSBC",
        showClauseTab:false,
        showClauseForm:true,
        groupMemberIsInvalid:false,
        clauseCodeIsInvalid:false,
        clauseTypeIsInvalid:false,
        fieldRejected:false,
        selectedClauseType:{}
      };
      this.clauseCodeRegex=/^[a-zA-Z0-9]*$/;
      this.handleInputChange = this.handleInputChange.bind(this);
      this.redirectToHome = this.redirectToHome.bind(this);
      this.createNewClause = this.createNewClause.bind(this);
      this.validateFields = this.validateFields.bind(this);
      this.saveCreateClause = this.saveCreateClause.bind(this);
  }
  onSearch() {
    var groupMember=React.findDOMNode(this.refs.group_member).value
      if(groupMember===""){
        this.setState({groupMemberIsInvalid:true})
      }else{
      this.setState({groupMemberIsInvalid:false})
      if(this.state.selectedClauseType!=''&&this.state.clauseCode!=''){
        this.dataToLoaded(this.state.clauseCode);
        this.setState({clauseCode:""})
        this.setState({showClauseTab:true,showClauseForm:false});
      }
       else{
         this.context.router.push('/tableClause');
       }

    }

  }
  createNewClause(){
  var flag=this.validateFields();
    if(flag){
      var clauseFlag = this.dataToLoadedCreate(this.state.clauseCode);
      if(clauseFlag){
        this.resultData= {
          "clauseId": this.state.selectedClauseType.id,
          "clauseCode": this.state.clauseCode,
          "clauseType": this.state.selectedClauseType.accountType,
          "clauseText": ""
        }
        this.setState({showClauseTab:true,showClauseForm:false});
      }else {
        this.setState({clauseCode:""})
      }

    }
  }

  saveCreateClause(){
    const postClause= {
      clauseId: this.state.selectedClauseType.id,
      clauseCode: this.state.clauseCode,
      clauseType: this.state.selectedClauseType.accountType,
      clauseText: this.refs.showClauseId.state.clauseText,
      groupMember:"HSBC"
    }
    this.setState({selectedClauseType:{},clauseCode:""});
    this.props.saveClauseCreate(postClause).then(()=>{
      this.context.router.push('/clause');
    })
  }
  validateFields(){

    var allValid=false;
    var clauseCodeInput=React.findDOMNode(this.refs.clause_code).value;
    var clauseType=React.findDOMNode(this.refs.clause_type);
    var groupMember=React.findDOMNode(this.refs.group_member).value
    if(groupMember===""){
      this.setState({groupMemberIsInvalid:true})
    }else{
      this.setState({groupMemberIsInvalid:false})
    }
    var clauseTypeInput=clauseType.children[0].children[0].children[0].innerText;
    if(clauseCodeInput===""|| clauseTypeInput==="PLEASE SELECT"){
      this.setState({fieldRejected:true})
      if(clauseCodeInput==="" && clauseTypeInput!="PLEASE SELECT"){
        this.setState({clauseCodeIsInvalid:true,clauseTypeIsInvalid:false})
      }else if(clauseTypeInput==="PLEASE SELECT" && clauseCodeInput!=""){
        this.setState({clauseTypeIsInvalid:true,clauseCodeIsInvalid:false})
      }else{
        this.setState({fieldRejected:true,clauseTypeIsInvalid:true,clauseCodeIsInvalid:true})
        this.state.fieldRejected=true;
        this.state.clauseTypeIsInvalid=true;
        this.state.clauseCodeIsInvalid=true;
      }
    }else{
      this.state.fieldRejected=false;
      this.state.clauseTypeIsInvalid=false;
      this.state.clauseCodeIsInvalid=false;
    }

    if(!this.state.groupMemberIsInvalid && !this.state.clauseCodeIsInvalid && !this.state.clauseTypeIsInvalid){
      allValid=true
    }
    return allValid;
  }
  handleInputChange(event) {
      const target = event.target;
      const name = target.name;
      this.setState({
        [name]: target.value
      });
    }
    handleClauseTypeSelection(eventVal,item){
      console.log("Selected item is", item)
      this.setState({selectedClauseType:item});
    }
  render() {
    if(!this.props.data.ResultList){
      return <div>Loading....</div>
    }
   else {
    return (
      <div className="row">
        {this.state.showClauseForm ?<div className="col-lg-12">
        <div>
          { !this.state.groupMemberIsInvalid && this.state.fieldRejected ?<span className="errorMessage">FE is rejected</span>:null}
          {this.state.groupMemberIsInvalid?<span className="errorMessage">Function not authorized</span>:null}
          {!this.state.groupMemberIsInvalid &&this.state.clauseTypeIsInvalid?<span className="errorMessage">Clause type is mandatory</span>:null}
          { !this.state.groupMemberIsInvalid && this.state.clauseCodeIsInvalid?<span id="clausecode-error" className="errorMessage">Clause code is mandatory</span>:null}
       </div>
       <div className="row">
       <div className="col-lg-6">
          <div className="margin_top">
            <label >Country code</label>
            <p>JP</p>
         </div>
         <div className="marginTop">
            <label>Clause type</label>
            <InputDropdownComponent
             ref="clause_type"
             name="dropDown"
             validateDropdown={(eventVal,item)=>this.handleClauseTypeSelection(eventVal,item)}/>
         </div>
       </div>

       <div className="col-lg-6">
         <div className="margin_top">
           <label>Group member</label>
           <div className="groupMember">
            <input ref="group_member" type="text" name="groupMember"
             value={this.state.groupMember}
             onChange={(event)=>this.handleInputChange(event)}/>

          </div>
         </div>
         <div className="margin_top">
          <label>Clause code</label>
           <div className="clauseCode">
            <input id="clause-code" ref="clause_code" type="text" name="clauseCode"
              value={this.state.clauseCode} maxLength="8"
              onChange={(event)=>this.handleInputChange(event)}/>

          </div>
         </div>
       </div>
</div>
            <div className="col-lg-12 control-padding">

                <div className="col-lg-6"></div>
                <div className="col-lg-6">
                     <button type="submit" className="btn btn-primary control-margin"  onClick={this.onSearch.bind(this)}>Search</button>
                     <button className="btn btn-primary control-margin" onClick={()=>this.createNewClause()}>Create New</button>
                     <button className="btn btn-primary control-margin">Print</button>
                     <Link to="/" className="btn btn-primary control-margin">Exit</Link>
                </div>
            </div>
          </div>
          :null}
            <div className="col-lg-12">
                {this.state.showClauseTab ?<ShowClause clauseDataList={this.resultData} saveCreateClause={this.saveCreateClause} redirectToHome={this.redirectToHome} ref="showClauseId"/>:null}
            </div>
      </div>
    );
  }}
}
function mapStateToProps(state){
  return { data:state.clauseData.all};
}

export default connect(mapStateToProps, { fetchClause,saveClauseCreate})(FormClause);
