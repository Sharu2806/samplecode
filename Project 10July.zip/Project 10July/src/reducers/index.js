import { combineReducers } from 'redux';
import clauseFetchReducer from './reducer-postclause';

 const rootReducer = combineReducers({
   clauseData:clauseFetchReducer
 });


 export default rootReducer;
