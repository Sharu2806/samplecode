import axios from 'axios';
 export const FETCH_CLAUSE = 'FETCH_CLAUSE';

// CONST ROOT_URL = '';

 export function fetchClause(){
   //const request = axios.get(ROOT_URL);
   const data = {

    "ResultList": [
      {
        "clauseId": "1",
        "clauseCode": "ACC",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "/REC/DRAFTS ACCEPTED TO BE MATURED"
      },
      {
        "clauseId": "2",
        "clauseCode": "AMDNZD",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "/PLS TREAT THIS AS FLD 79/PLS READ"
      },
      {
        "clauseId": "3",
        "clauseCode": "BBI01",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "PLEASE DO NOT RELEASE THIS CREDIT"
      },
      {
        "clauseId": "4",
        "clauseCode": "BENCONS",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "THIS AMENDMENT IS SUBJECT TO"
      },
      {
        "clauseId": "5",
        "clauseCode": "BOJ",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "//PLS REMIT PROCEEDS THRU FOREIGN"
      },
      {
        "clauseId": "6",
        "clauseCode": "CBLNEGO",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "DATE OF DOC'S PRESENTED: DDMMMYYYY"
      },
      {
        "clauseId": "7",
        "clauseCode": "DISIMP6",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "IN ACCORDANCE WITH ART 16 OF UCP"
      },
      {
        "clauseId": "8",
        "clauseCode": "EQU",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "/REC/"
      },
      {
        "clauseId": "9",
        "clauseCode": "FHI2",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "PLS ADVISE REINSTATED AMT THRU YR"
      },
      {
        "clauseId": "10",
        "clauseCode": "JB",
        "clauseType": "BANK TO BANK INSTRUCTIONS",
        "clauseText": "/BNF/BILL PROCEEDS"
      }
    ]

};
   return {
     type:FETCH_CLAUSE,
     payload:data
   }
 }

 export function saveClauseCreate(post){
   console.log(post);
    //const request = axios.get(ROOT_URL);
   return {
     type:FETCH_CLAUSE,
     payload:""
   }
 }
//
