import React from 'react';
import { Provider,connect } from 'react-redux';
import ReactDOM from 'react-dom';
import { shallow,mount } from 'enzyme';
import { createStore} from 'redux';
import FormClause from '../components/createClauseContainer.js';
import Reducer from '../reducers/index.js'

let store = createStore(Reducer);


let app;
    beforeEach(() => {
        app  = mount(<Provider store={store}>
          <FormClause />
        </Provider>);
    })

describe('FormClause', () => {
  //For rendering the form
    it('renders without crashing', () => {
        const div = document.createElement('div');
        ReactDOM.render(<app/>, div);
    });
    //To check default value of Group member
    it ('should have default state val for Group Member', () => {
       app.setProps({ groupMember: "HSBC" });
       expect(app.props().groupMember).toBe("HSBC");
   });

});
